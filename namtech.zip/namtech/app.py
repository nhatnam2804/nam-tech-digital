"""NAM TECH DIGITAL - Flask app. Chạy: flask --app app run  |  Tạo admin: flask --app app create-admin 09xxxxxxxx"""
import os, re, uuid, click
from functools import wraps
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_wtf.csrf import CSRFProtect
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from authlib.integrations.flask_client import OAuth

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ["SECRET_KEY"],                 # BẮT BUỘC đặt biến môi trường
    SQLALCHEMY_DATABASE_URI=os.environ.get("DATABASE_URL", "sqlite:///namtech.db"),
    UPLOAD_FOLDER=os.path.join(app.root_path, "static", "uploads"),
    MAX_CONTENT_LENGTH=2 * 1024 * 1024,                  # 2MB/ảnh
    SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("PROD") == "1", # bật khi chạy HTTPS
)
db = SQLAlchemy(app); csrf = CSRFProtect(app)
login_manager = LoginManager(app); login_manager.login_view = "login"
oauth = OAuth(app)
oauth.register("google", client_id=os.environ.get("GOOGLE_ID"), client_secret=os.environ.get("GOOGLE_SECRET"),
               server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
               client_kwargs={"scope": "openid email profile"})
oauth.register("facebook", client_id=os.environ.get("FB_ID"), client_secret=os.environ.get("FB_SECRET"),
               access_token_url="https://graph.facebook.com/oauth/access_token",
               authorize_url="https://www.facebook.com/dialog/oauth",
               api_base_url="https://graph.facebook.com/", client_kwargs={"scope": "email public_profile"})

# ---------- MODELS ----------
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(15), unique=True)
    email = db.Column(db.String(120), unique=True)
    password_hash = db.Column(db.String(256))
    provider = db.Column(db.String(20), default="local")   # local/google/facebook
    provider_id = db.Column(db.String(100))
    role = db.Column(db.String(10), default="user", nullable=False)  # chỉ 'user' khi đăng ký
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Service(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(20), nullable=False)    # web / server / proxy
    name = db.Column(db.String(150), nullable=False)
    price = db.Column(db.Integer, nullable=False)
    description = db.Column(db.Text, default="")
    image = db.Column(db.String(200))
    active = db.Column(db.Boolean, default=True)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey("service.id"), nullable=False)
    status = db.Column(db.String(15), default="pending")   # pending/paid/done/cancelled
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship("User"); service = db.relationship("Service")

class Setting(db.Model):
    key = db.Column(db.String(50), primary_key=True)
    value = db.Column(db.Text, default="")

def get_setting(k, d=""):
    s = db.session.get(Setting, k); return s.value if s else d
def set_setting(k, v):
    s = db.session.get(Setting, k) or Setting(key=k); s.value = v; db.session.add(s)

@login_manager.user_loader
def load_user(uid): return db.session.get(User, int(uid))

@app.context_processor
def inject_globals():
    return dict(marquee=get_setting("marquee", "Chào mừng đến NAM TECH DIGITAL!"))

# ---------- HELPERS ----------
def admin_required(f):
    @wraps(f)
    @login_required
    def w(*a, **k):
        if current_user.role != "admin": abort(404)      # ẩn sự tồn tại của trang admin
        return f(*a, **k)
    return w

ALLOWED = {"png", "jpg", "jpeg", "webp"}
def save_image(file):
    """Trả về tên file đã lưu hoặc None. Chặn đuôi lạ, đổi tên ngẫu nhiên."""
    if not file or not file.filename: return None
    ext = secure_filename(file.filename).rsplit(".", 1)[-1].lower()
    if ext not in ALLOWED: flash("Chỉ chấp nhận ảnh png/jpg/webp", "error"); return None
    name = f"{uuid.uuid4().hex}.{ext}"
    file.save(os.path.join(app.config["UPLOAD_FOLDER"], name)); return name

PHONE_RE = re.compile(r"^(0|\+84)\d{9}$")
def norm_phone(p): return re.sub(r"[\s.-]", "", p or "")

# ---------- PUBLIC ----------
@app.route("/")
def index():
    services = Service.query.filter_by(active=True).all()
    return render_template("index.html", services=services)

@app.route("/order/<int:sid>", methods=["POST"])
@login_required
def order(sid):
    s = db.get_or_404(Service, sid)
    o = Order(user_id=current_user.id, service_id=s.id); db.session.add(o); db.session.commit()
    return redirect(url_for("checkout", oid=o.id))

@app.route("/checkout/<int:oid>")
@login_required
def checkout(oid):
    o = db.get_or_404(Order, oid)
    if o.user_id != current_user.id: abort(404)
    return render_template("checkout.html", o=o, qr=get_setting("qr_image"), bank=get_setting("bank_info"))

@app.route("/my-orders")
@login_required
def my_orders():
    return render_template("my_orders.html", orders=Order.query.filter_by(user_id=current_user.id).order_by(Order.id.desc()).all())

# ---------- AUTH ----------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        phone, name, pw = norm_phone(request.form["phone"]), request.form["name"].strip(), request.form["password"]
        if not PHONE_RE.match(phone) or len(pw) < 8 or not name:
            flash("SĐT không hợp lệ hoặc mật khẩu < 8 ký tự", "error")
        elif User.query.filter_by(phone=phone).first():
            flash("SĐT đã được đăng ký", "error")
        else:
            u = User(name=name, phone=phone, password_hash=generate_password_hash(pw), role="user")  # luôn 'user'
            db.session.add(u); db.session.commit(); login_user(u); return redirect(url_for("index"))
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = User.query.filter_by(phone=norm_phone(request.form["phone"])).first()
        if u and u.password_hash and check_password_hash(u.password_hash, request.form["password"]):
            login_user(u); nxt = request.args.get("next", "")
            return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else url_for("index"))
        flash("Sai số điện thoại hoặc mật khẩu", "error")
    return render_template("auth.html", mode="login")

@app.route("/logout", methods=["POST"])
@login_required
def logout(): logout_user(); return redirect(url_for("index"))

@app.route("/oauth/<provider>")
def oauth_start(provider):
    if provider not in ("google", "facebook"): abort(404)
    return oauth.create_client(provider).authorize_redirect(url_for("oauth_callback", provider=provider, _external=True))

@app.route("/oauth/<provider>/callback")
def oauth_callback(provider):
    if provider not in ("google", "facebook"): abort(404)
    c = oauth.create_client(provider); token = c.authorize_access_token()
    if provider == "google":
        info = token.get("userinfo") or c.userinfo(); pid, email, name = info["sub"], info.get("email"), info.get("name")
    else:
        info = c.get("me?fields=id,name,email", token=token).json(); pid, email, name = info["id"], info.get("email"), info.get("name")
    u = User.query.filter_by(provider=provider, provider_id=pid).first()
    if not u:
        u = User(name=name or "Khách", email=email, provider=provider, provider_id=pid, role="user")  # luôn 'user'
        db.session.add(u); db.session.commit()
    login_user(u); return redirect(url_for("index"))

# ---------- ADMIN ----------
@app.route("/admin")
@admin_required
def admin():
    return render_template("admin/dashboard.html", services=Service.query.all(),
        users=User.query.order_by(User.id.desc()).all(), orders=Order.query.order_by(Order.id.desc()).all(),
        qr=get_setting("qr_image"), bank=get_setting("bank_info"))

@app.route("/admin/service/save", methods=["POST"])
@admin_required
def admin_service_save():
    f = request.form; s = db.session.get(Service, int(f["id"])) if f.get("id") else Service()
    s.category = f["category"] if f["category"] in ("web", "server", "proxy") else "web"
    s.name, s.description = f["name"].strip(), f["description"].strip()
    s.price = max(0, int(f.get("price") or 0)); s.active = "active" in f
    img = save_image(request.files.get("image"))
    if img: s.image = img
    db.session.add(s); db.session.commit(); flash("Đã lưu dịch vụ", "ok"); return redirect(url_for("admin"))

@app.route("/admin/service/<int:sid>/delete", methods=["POST"])
@admin_required
def admin_service_delete(sid):
    db.session.delete(db.get_or_404(Service, sid)); db.session.commit(); return redirect(url_for("admin"))

@app.route("/admin/settings", methods=["POST"])
@admin_required
def admin_settings():
    set_setting("marquee", request.form.get("marquee", "").strip()[:500])
    set_setting("bank_info", request.form.get("bank_info", "").strip()[:500])
    qr = save_image(request.files.get("qr"))
    if qr: set_setting("qr_image", qr)
    db.session.commit(); flash("Đã cập nhật cài đặt", "ok"); return redirect(url_for("admin"))

@app.route("/admin/order/<int:oid>/status", methods=["POST"])
@admin_required
def admin_order_status(oid):
    st = request.form["status"]
    if st in ("pending", "paid", "done", "cancelled"):
        db.get_or_404(Order, oid).status = st; db.session.commit()
    return redirect(url_for("admin"))

# ---------- CLI ----------
@app.cli.command("create-admin")
@click.argument("phone")
def create_admin(phone):
    """Tạo/nâng quyền admin an toàn từ dòng lệnh."""
    pw = click.prompt("Mật khẩu", hide_input=True, confirmation_prompt=True)
    u = User.query.filter_by(phone=phone).first() or User(phone=phone, name="Admin")
    u.password_hash, u.role = generate_password_hash(pw), "admin"
    db.session.add(u); db.session.commit(); click.echo("OK")

with app.app_context(): db.create_all()
