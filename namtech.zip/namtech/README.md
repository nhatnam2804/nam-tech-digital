# NAM TECH DIGITAL (Flask)
pip install -r requirements.txt
export SECRET_KEY="chuoi-ngau-nhien-dai"  GOOGLE_ID=... GOOGLE_SECRET=... FB_ID=... FB_SECRET=...
flask --app app create-admin 09xxxxxxxx     # tạo admin (hỏi mật khẩu)
flask --app app run
Đặt logo: static/logo.png, ảnh hero: static/hero.png. Production: PROD=1, HTTPS, gunicorn + nginx.
